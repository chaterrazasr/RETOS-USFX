KEYS = ['..redacted..','..redacted..','..redacted..','..redacted..','..redacted..','..redacted..']

def xor_strings(a, b):
   return bytes(x ^ y for x, y in zip(a.encode(), b.encode()))

MESSAGES = ['AAAAAAAA','BBBBBBBB','CCCCCCCC','DDDDDDDD','EEEEEEEE','...flag...']

ENCRYPTED = []

for i in range(len(KEYS)):
   ENCRYPTED.append(xor_strings(KEYS[i], MESSAGES[i]).decode())

for i in ENCRYPTED:
   print(i)
